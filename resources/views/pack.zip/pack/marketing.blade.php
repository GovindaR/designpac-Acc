<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Marketing</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->
<!-- bootstrpe -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Heebo:300,400,500,700,800,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik" rel="stylesheet">

  <link rel="stylesheet" href="{{url('/')}}/resources/views/pack/css/normalize.css">
  <link rel="stylesheet" href="{{url('/')}}/resources/views/pack/css/main.css">
    <link rel="stylesheet" href="{{url('/')}}/resources/views/pack/css/responsive.css">
</head>

<body class="marketing">
  <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

  <!-- Add your site or application content here -->
   <?php 
    // \Stripe\Stripe::setApiKey(config('services.stripe.secret'));

   //  $plansall = \Stripe\Plan::retrieve('plan_DfVkGC5NiWbnnu');
    // dd($plansall);
    // $plansall = substr($plansall,24);
//echo $plansall;
    ?>

 <script>
     /*var data = [];
     data = <?php //echo $plansall;?>;
     console.log(data.data[0].id);
      for(var i="0";i<data.data.length;i++){
      if(data.data[i].nickname == "marketing"){
        
      }*/
     // $('.as-service').eq(i).attr("data-plan-id",data.data[i].id);
     // }
     //$('#plan').html(html);  
            
   </script>
  <section class="desired-package">
    <div class="container">
      <div class="row">
        <a href="https://www.designpac.net/"><img src="{{url('/')}}/resources/views/pack/img/designpac.png" alt="designpac"></a>
        <div class="services">
          <h4>
           Choose your desired package
          </h4>
          <form action="./payment" method="post">
          <div class="container-service">
             <ul>

             </ul>
          </div>        
          <div class="buttom-next clearfix">
            <a class="back-button" href="{{url('/')}}/pack"><i class="fas fa-minus"></i>Back</a>
            
            <button type="submit"  class="next-button">Next <i class="fas fa-minus"></i></button>            
          </div>
        </form>
        </div>
      </div>
    </div>
  </section>

 
  <script src="{{url('/')}}/resources/views/pack/js/vendor/modernizr-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script>window.jQuery || document.write('<script src="{{url('/')}}/resources/views/pack/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
  <script src="{{url('/')}}/resources/views/pack/js/plugins.js"></script>
  <script src="{{url('/')}}/resources/views/pack/js/main.js"></script>
<script type="text/javascript">
   var nData = localStorage.getItem("package");
         nData = JSON.parse(nData);
         
         var html =""  ;       
             for(var i =0;i<nData.Marketing.length;i++){
                 html += '<li class="col-sm-4">\
                 <input id="frontend'+i+'" type="radio" name="product" value="'+nData.Marketing[i].planID+'">\
          <label for="frontend'+i+'">\
          <div>\
          <input type="radio" name="amount" value="'+parseFloat(nData.Marketing[i].amount/100).toFixed(2)+'">\
          <input type="radio" name="plan_name" value="'+nData.Marketing[i].name+'">\
          <input type="radio" name="product_id" value="">\
          <input type="radio" name="sku" value="">\
              <a href="#">\
                <span class="merket-number">\
                  '+(i+1)+'\
                </span>\
                <p>'+nData.Marketing[i].name+'</p>\
                <small>$'+parseFloat(nData.Marketing[i].amount/100).toFixed(2)+'</small>\
              </a>\
            </div>\
            </label>\
            </li>';
            } 
            $('.container-service ul').html(html) ;   

        $('label').on("click",function(){
        var siblings = $(this).parent().siblings();
        var $labelId = $(this).attr("for");
        $('#'+$labelId).prop("checked",true);
        $('#'+$labelId).next().prop("checked",true);
        $('#'+$labelId).next().next().prop("checked",true);
        $('#'+$labelId).next().next().next().prop("checked",true);
        $('#'+$labelId).next().next().next().next().prop("checked",true);
        
        if($('#'+$labelId).is(':checked')){
         siblings.find('input[type="radio"]').prop("checked",false);
        }
        });
</script>

</body>

</html>
