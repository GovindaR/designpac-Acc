<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Design</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->
<!-- bootstrpe -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Heebo:300,400,500,700,800,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik" rel="stylesheet">

  <link rel="stylesheet" href="{{url('/')}}/resources/views/pack/css/normalize.css">
  <link rel="stylesheet" href="{{url('/')}}/resources/views/pack/css/main.css">
  <link rel="stylesheet" href="{{url('/')}}/resources/views/pack/css/responsive.css">
</head>

<body class="marketing">
  <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

  <!-- Add your site or application content here -->
  <section class="desired-package">
    <div class="container">
      <div class="row">
        <a href="https://www.designpac.net/"><img src="{{url('/')}}/resources/views/pack/img/designpac.png" alt="designpac"></a>
        <div class="services">
          <h4>
           Choose your desired package
          </h4>
          <div class="container-service">
            <div class="col-sm-4 purches">
              sdadasd
            </div>
            <div class="col-sm-8">
              <a href="#" class="as-service">
                <span class="merket-number">
                  2
                </span>
                <p>Semiannual Plan</p>
                <small>$1500</small>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

 
  <script src="{{url('/')}}/resources/views/pack/js/vendor/modernizr-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script>window.jQuery || document.write('<script src="{{url('/')}}/resources/views/pack/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
  <script src="{{url('/')}}/resources/views/pack/js/plugins.js"></script>
  <script src="{{url('/')}}/resources/views/pack/js/main.js"></script>

  <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
  <script>
    window.ga = function () { ga.q.push(arguments) }; ga.q = []; ga.l = +new Date;
    ga('create', 'UA-XXXXX-Y', 'auto'); ga('send', 'pageview')
  </script>
  <script src="https://www.google-analytics.com/analytics.js" async defer></script>
</body>

</html>
