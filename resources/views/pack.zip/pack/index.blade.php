<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>package</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->
<!-- bootstrpe -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Heebo:300,400,500,700,800,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik" rel="stylesheet">

  <link rel="stylesheet" href="./resources/views/pack/css/normalize.css">
  <link rel="stylesheet" href="./resources/views/pack/css/main.css">
  <link rel="stylesheet" href="./resources/views/pack/css/responsive.css">
</head>

<body>
                   <?php 
                   \Stripe\Stripe::setApiKey(config('services.stripe.secret'));



                   $plansall =  \Stripe\Plan::all(array("limit" => 17));;

                   $plansall = substr($plansall,23);

                   $productall =  \Stripe\Product::all(array("limit" => 25));;

                   $productall = substr($productall,23);
                  //dd($productall);?>
  

  <!-- Add your site or application content here -->
  <section class="desired-package">
    <div class="container">
      <div class="row">
        <a href="https://www.designpac.net/"><img src="./resources/views/pack/img/designpac.png" alt="designpac"></a>
        <div class="services">
          <h4>
            Which service do you want?
          </h4>
          <div class="container-service" id="dpac">
            <div class="col-sm-4">
              <a href="./designs" class="as-service" data-plan-id="">
                <span>
                  <img src="https://www.designpac.net/wp-content/uploads/2018/09/design.svg" alt="design">
                </span>
                <p>Design As A Service</p>
              </a>
            </div>
            
            <div class="col-sm-4">
              <a href="./developers" class="as-service" data-plan-id="">
                <span>
                  <img src="https://www.designpac.net/wp-content/uploads/2018/09/development.svg" alt="design">
                </span>
                <p>Development As A Service</p>
              </a>
            </div>

            <div class="col-sm-4">
               <a href="./marketings" class="as-service" data-plan-id="">
                <span>
                  <img src="https://www.designpac.net/wp-content/uploads/2018/09/development.svg" alt="design">
                </span>
                <p>Marketing As A Service</p>
              </a>
            </div>
         
          </div>
        </div>
      </div>
    </div>
  </section>

 

 
  <script src="./resources/views/pack/js/vendor/modernizr-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script>window.jQuery || document.write('<script src="./resources/views/pack/js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
  <script src="{{url('/')}}/resources/views/pack/js/plugins.js"></script>
  <script src="{{url('/')}}/resources/views/pack/js/main.js"></script>
   


<script>
  var newData={
         "Marketing":[],
         "Development":[],
         "Design": []
     };

     var HourlyNewData = [];
     function checkNickname(nickname){
         var subnickname = nickname.split(":")[1];
         subnickname = subnickname.replace(/\s/g,'');
         return subnickname;
     }
     function trimName(nickname){
      var trimname = nickname.split(":")[0];
      trimname = trimname.split("-")[1];
      //console.log(trimname);
      return trimname;
     }
    

          var data = [];
           data = <?php echo $plansall; ?>;
           var hourlyProduct = <?php echo $productall;?>;
           var options = ["ADev","BDev","CMSDev","HDev","FSDev","D","M","iOSDev","WMDev","FDev"];
           for(var i=0;i<hourlyProduct.data.length;i++){
            if(options.indexOf(hourlyProduct.data[i].caption) !== -1) {
             HourlyNewData.push( {
      "productID":hourlyProduct.data[i].id,
      "planID": "",
      "name": hourlyProduct.data[i].name,
      "caption": hourlyProduct.data[i].caption,
      "amount": JSON.parse(hourlyProduct.data[i].attributes[0]),
      "sku": JSON.parse(hourlyProduct.data[i].attributes[1])
     });
           
}
           
           }
           //console.log(HourlyNewData);
function upDateHourly(nm,planId){
      for(var i=0;i<HourlyNewData.length;i++){
        if(HourlyNewData[i].caption == nm){
          HourlyNewData[i].planID = planId;
        }
      }
}
           var html = "",nm="";
          //$('#dpac').html(data.data[0].id);
           for(var i=0; i<data.data.length;i++){
              html += "<p>"+data.data[i].id+"</p>";
               nm = checkNickname(data.data[i].nickname);
              //planName = trimName(data.data[i].nickname);
              // html += "<strong>"+nm+"</strong>";
               //console.log(nm);
               if(nm == "M"){
                   newData.Marketing.push( {
                    "planID":data.data[i].id,
                    "productID":data.data[i].product,
                    "amount":data.data[i].amount,
                    "sku":trimName(data.data[i].nickname),
                    "name":trimName(data.data[i].nickname)
                  } );
                   upDateHourly(nm,data.data[i].id);
               }else if(nm == "FSDev" || nm == "FDev" || nm == "BDev" || nm == "WMDev" || nm == "ADev" || nm == "iOSDev" || nm == "HDev"){
                   newData.Development.push( {
                    "planID":data.data[i].id,
                    "productID":data.data[i].product,
                    "amount":data.data[i].amount,
                    "sku":trimName(data.data[i].nickname),
                   "name": trimName(data.data[i].nickname)
                  });
                   // if(nm == "FDev"){
                   //   HourlyNewData[].planID = data.data[i].id;
                   // }
                   upDateHourly(nm,data.data[i].id);
                  
               }else if(nm == "D"){
                   newData.Design.push({
                    "planID":data.data[i].id,
                    "productID":data.data[i].product,
                    "amount":data.data[i].amount,
                    "sku":trimName(data.data[i].nickname),
                   "name": trimName(data.data[i].nickname)
                  });
                   upDateHourly(nm,data.data[i].id);
               }
           }
           //$('#dpac').html(html);
           localStorage.setItem("hourly",JSON.stringify(HourlyNewData));
           localStorage.setItem("package",JSON.stringify(newData));
           document.cookie = "hourly = " + JSON.stringify(HourlyNewData);
           document.cookie = "package = " + JSON.stringify(newData);


           <?php
           
            $hrly= $_COOKIE['hourly'];
            $packs= $_COOKIE['package'];
            DB::table('hourlypack')->insert(
                ['hourly' => $hrly, 'pack' => $packs]
                );
            ?>

   //   $('#dpac a').on("click",function(e){
   //       e.preventDefault();
   //       $target = $(this).attr("href");
   //       var nData = localStorage.getItem("package");
   //       nData = JSON.parse(nData);
   //       var html = "";
   //       if($target == "marketings"){
   //           html = "";
   //           for(var i =0;i<nData.Marketing.length;i++){
   //               html += '<a href="#">'+nData.Marketing[i].id+'</a>';
   //           }
   //           //$('#dpac').html(html);
   //       }else if($target == "developers"){
   //           html = "";
   //           for(var i =0;i<nData.Development.length;i++){
   //               html += '<a href="#">'+nData.Development[i].id+'</a>';
   //           }
   //           //$('#dpac').html(html);
   //       }else if($target == "designs"){
   //           html = "";
   //           for(var i =0;i<nData.Design.length;i++){
   //               html += '<a href="#">'+nData.Design[i].id+'</a>';
   //           }
   //           //$('#dpac').html(html);
   //       }
   //       $('#dpac').html(html);


   // });
 </script>


  <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
  <script>
    window.ga = function () { ga.q.push(arguments) }; ga.q = []; ga.l = +new Date;
    ga('create', 'UA-XXXXX-Y', 'auto'); ga('send', 'pageview')
  </script>
  <script src="https://www.google-analytics.com/analytics.js" async defer></script>
</body>

</html>
