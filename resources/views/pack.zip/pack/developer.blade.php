<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Development</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->
<!-- bootstrpe -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Heebo:300,400,500,700,800,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik" rel="stylesheet">

  <link rel="stylesheet" href="{{url('/')}}/resources/views/pack/css/normalize.css">
  <link rel="stylesheet" href="{{url('/')}}/resources/views/pack/css/main.css">
  <link rel="stylesheet" href="{{url('/')}}/resources/views/pack/css/responsive.css">
</head>

<body class="developer-body">

                  <?php 
                   \Stripe\Stripe::setApiKey(config('services.stripe.secret'));



                   //$plansall = \Stripe\Product::all();
                   $plansall = \Stripe\Product::all(array("limit" => 17));

                   $plansall = substr($plansall,23);
                   //dd($plansall);?>
  <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

  <!-- Add your site or application content here -->
  <section class="desired-package">
    <div class="container">
      <div class="row">
        <a href="https://www.designpac.net/"><img src="{{url('/')}}/resources/views/pack/img/designpac.png" alt="designpac"></a>
        <div class="services">
          <h4>
           Select the developer
          </h4>
          <div class="container-service">
            <form action="./devdesire" method="post">
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
             <div class="col-sm-6" id="left">
              <ul>

              </ul>
             </div>
             <div class="col-sm-6" id="right">
            <ul>
              
            </ul>
             </div>
           
          </div>
          <div class="buttom-next clearfix">
            <a class="back-button" href="{{url('/')}}/pack"><i class="fas fa-minus"></i>Back</a>
            <button  type="submit"  class="next-button">Next <i class="fas fa-minus"></i></button>
            
           </form>
          </div>
        </div>
      </div>
    </div>
  </section>

 
  <script src="js/vendor/modernizr-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script>window.jQuery || document.write('<script src="js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
  <script src="./pack/js/plugins.js"></script>
  <script src="./pack/js/main.js"></script>

<script type="text/javascript">
var mainData = <?php echo $plansall; ?>;
var nData = localStorage.getItem("package");
nData = JSON.parse(nData);   
var html =""  ;       
//console.log(nData.Development.length);

  function checkInDev(prodId,prodName){
      for(var j=0;j<nData.Development.length;j++){
        if(nData.Development[j].productID == prodId ){
          //console.log("Matched"+prodId);
          html = '<li>\
                  <input id="frontend'+j+'" type="radio" name="product" value="'+nData.Development[j].planID+'">\
                   <label for="frontend'+j+'">\
                     \
                     <div class="frontend-detail">\
                       <div class="img-frontend">\
                       <img src="{{url('/')}}/resources/views/pack/img/html.png" alt="html">\
                     </div>\
                     <div class="text-frontend">\
                       <h4>'+prodName+'</h4>\
                       <p>All type of language & platform</p>\
                     </div>\
                     </div>\
                   </label>\
                 </li>';
                 if(j%2 == 0){
                  $('#left ul').append(html);
                 }else{
                   $('#right ul').append(html);
                 }
        }
      }
      //$('.container-service ul').html(html);
     //console.log(html);
  }
for(var i=0;i<mainData.data.length;i++){
 checkInDev(mainData.data[i].id,mainData.data[i].name);
}
 
   
  
</script>
  <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
  <script>
    window.ga = function () { ga.q.push(arguments) }; ga.q = []; ga.l = +new Date;
    ga('create', 'UA-XXXXX-Y', 'auto'); ga('send', 'pageview')
  </script>
  <script src="https://www.google-analytics.com/analytics.js" async defer></script>
</body>

</html>
